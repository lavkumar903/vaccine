import React from "react";
import { Form, Button, Input } from "antd";

class Admin extends React.Component {
  render() {
    return <></>;
  }
}

export default Admin;
